Fits the v2 ar-15 standard magazine.
Needs a #10 screw 3" long and a #10 hex nut to clamp.
Enjoy the Texas state outline and Come and Take It flag.
-md123