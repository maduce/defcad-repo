* WARNING: DO NOT PRINT THIS ITEM IF YOU HAVE ALREADY PRINTED MY 12 GAUGE FLARE PISTOL DESIGN.  DOING SO MAY PUT YOU IN "CONSTRUCTIVE POSSESSION" OF AN NFA ITEM! *

Converts a 12 gauge shotgun to fire low pressure .22 rounds.  Use in (or possession with) a polymer flare pistol may violate the Undetectable Firearm Act.  Use in any pistol may constitute an AOW or "Unconventional Pistol" subject to NFA registration.

This design is hereby released into the public domain.  Have fun.

~ Pietro